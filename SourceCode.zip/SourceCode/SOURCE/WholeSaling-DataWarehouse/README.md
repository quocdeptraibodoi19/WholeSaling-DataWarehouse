# WholeSaling-DataWarehouse

## Software Architecture:
![Data Warehouse Architecture](./concrete-system-architecture.png)

