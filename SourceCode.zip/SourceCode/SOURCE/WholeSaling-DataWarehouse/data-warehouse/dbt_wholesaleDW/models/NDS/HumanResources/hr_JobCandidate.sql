/*
NotImplement:
JobCandidate (Seems like there is some errors with the data ingestion but not on the priority so delay implementing this). 
*/