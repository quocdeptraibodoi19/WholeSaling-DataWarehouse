drop database Ecomerce;
drop database HumanResourceSystem;
drop database Product;
drop database WholeSaling;


create database Ecomerce;
create database HumanResourceSystem;
create database Product;
create database WholeSaling;